/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package absentsproject;

/**
 *
 * @author Blnd
 */
class Webdesign extends Lectures {
public void WD(){    
    Lectures obj=new Lectures();
        Mathematics obj2=new Mathematics();
super.set_l_name("Programing :");
super.set_h_perweek(4);
super.set_total_h_persem(32);
}
public void transfere(int semesterab){
     int set_ab_persem=semesterab;
    
}}    